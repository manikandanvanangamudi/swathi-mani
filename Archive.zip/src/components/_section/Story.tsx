const Story = () => {
  return (
    <div className="h-screen w-full bg-white">
      <h1>Story</h1>
    </div>
  )
}

export default Story