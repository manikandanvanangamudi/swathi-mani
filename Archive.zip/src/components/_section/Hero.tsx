import RevealText from "@/components/ui/RevealText";
import ImageSlideshow from "@/components/ui/ImageSlideshow";
import { Playfair } from "next/font/google";

const playfair = Playfair({ subsets: ["latin"] });

const IMAGES = ["/Hero.png", "/Hero2.png", "/Hero3.png"];

interface HeroProps {
  revealed?: boolean;
}

const Hero = ({ revealed = false }: HeroProps) => {
  const trigger = revealed ? "instant" : "none";

  return (
    // relative + explicit height is required for fill images inside
    <div className="relative h-screen w-full">
      {/* ImageSlideshow fills the full parent — parent must be relative+sized */}
      <ImageSlideshow
        images={IMAGES}
        interval={5000}
        fadeDuration={1500}
        className="absolute inset-0"
        imgClassName="grayscale"
        overlay={<div className="w-full h-full bg-black/50" />}
      />

      {/* Text content sits above slideshow */}
      <div className="relative z-10 w-full h-full flex flex-col items-center justify-center p-4 md:p-8 text-white gap-8">
        <RevealText
          as="h1"
          trigger={trigger}
          mode="sentence"
          delay={1}
          duration={0.8}
          className="text-sm text-center"
        >
          You're Invited to Celebrate The Wedding of
        </RevealText>

        <RevealText
          as="h1"
          trigger={trigger}
          mode="sentence"
          delay={1.2}
          duration={0.8}
          className={`${playfair.className} text-5xl md:text-7xl`}
        >
          Cindy
        </RevealText>

        <RevealText
          as="h1"
          trigger={trigger}
          mode="sentence"
          delay={1.4}
          duration={0.8}
          className={`${playfair.className} text-5xl md:text-7xl`}
        >
          And
        </RevealText>

        <RevealText
          as="h1"
          trigger={trigger}
          mode="sentence"
          delay={1.6}
          duration={0.8}
          className={`${playfair.className} text-5xl md:text-7xl`}
        >
          Roby
        </RevealText>
      </div>
    </div>
  );
};

export default Hero;
