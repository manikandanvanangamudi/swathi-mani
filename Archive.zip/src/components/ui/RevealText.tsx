"use client";

import { useEffect, useRef, useState } from "react";

type Tag = "h1" | "h2" | "h3" | "h4" | "h5" | "h6" | "p" | "span" | "div";
type Mode = "sentence" | "word" | "line";
type Trigger = "viewport" | "instant" | "none";

interface RevealTextProps {
  as?: Tag;
  children: string;
  mode?: Mode;
  trigger?: Trigger;
  delay?: number;
  duration?: number;
  stagger?: number;
  className?: string;
  once?: boolean;
}

export default function RevealText({
  as: Tag = "p",
  children,
  mode = "sentence",
  trigger = "viewport",
  delay = 0,
  duration = 0.75,
  stagger = 0.08,
  className = "",
  once = true,
}: RevealTextProps) {
  const ref = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (trigger === "none") {
      setVisible(false);
      return;
    }

    if (trigger === "instant") {
      // Small rAF so the element is painted before we animate
      const id = requestAnimationFrame(() => setVisible(true));
      return () => cancelAnimationFrame(id);
    }

    // viewport
    const el = ref.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          if (once) observer.disconnect();
        } else if (!once) {
          setVisible(false);
        }
      },
      { threshold: 0.1 },
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, [trigger, once]);

  const units: string[] = (() => {
    if (mode === "word") return children.split(" ").filter(Boolean);
    if (mode === "sentence")
      return children
        .split(/(?<=[.!?])\s+/)
        .map((s) => s.trim())
        .filter(Boolean);
    return children.split("\n").filter(Boolean);
  })();

  const isSingleUnit = units.length <= 1;

  const unitStyle = (i: number): React.CSSProperties => {
    const unitDelay = delay + i * stagger;
    return {
      display: "block",
      transform: visible ? "translateY(0)" : "translateY(110%)",
      opacity: visible ? 1 : 0,
      transition: visible
        ? `transform ${duration}s cubic-bezier(0.16,1,0.3,1) ${unitDelay}s, opacity ${duration * 0.6}s ease ${unitDelay}s`
        : "none",
      willChange: "transform",
    };
  };

  return (
    // @ts-ignore
    <Tag ref={ref} className={className}>
      {isSingleUnit ? (
        <span style={{ display: "block", overflow: "hidden" }}>
          <span style={unitStyle(0)}>{children}</span>
        </span>
      ) : (
        units.map((unit, i) => (
          <span
            key={i}
            style={{
              display: mode === "word" ? "inline-block" : "block",
              overflow: "hidden",
              marginRight: mode === "word" ? "0.25em" : undefined,
            }}
          >
            <span style={unitStyle(i)}>{unit}</span>
          </span>
        ))
      )}
    </Tag>
  );
}
