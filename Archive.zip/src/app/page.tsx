"use client";

import { useState } from "react";

import Hero from "@/components/_section/Hero";
import Story from "@/components/_section/Story";
import Loader from "@/components/Loader";

export default function Home() {
  const [reveal, setReveal] = useState(true);

  return (
    <main className="w-full bg-[#FEF2E8]">
      {/* <Loader onComplete={() => setReveal(true)} /> */}

      <div
        className="transition-opacity duration-1400 ease-in-out"
        style={{ opacity: reveal ? 1 : 0 }}
      >
        <Hero revealed={reveal} />
        <Story />
      </div>
    </main>
  );
}
